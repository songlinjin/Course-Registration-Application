package exception;

public class InvalidCreditsException extends Exception{
}
