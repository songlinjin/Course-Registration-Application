package exception;

public class NotInWorkListException extends Exception{
}
